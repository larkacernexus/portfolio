'use client';

import { FaRobot, FaCode, FaDatabase, FaCloud, FaMobileAlt, FaDesktop } from 'react-icons/fa';
import { motion } from 'framer-motion';

export default function Skills() {
  const skillCategories = [
    {
      icon: FaCode,
      title: 'Frontend',
      skills: ['React', 'Inertia.js', 'Next.js', 'Vue.js', 'Tailwind CSS', 'JavaScript', 'TypeScript'],
      color: '#06b6d4'
    },
    {
      icon: FaDatabase,
      title: 'Backend & Database',
      skills: ['Laravel', 'PHP', 'Node.js', 'MySQL', 'REST APIs'],
      color: '#10b981'
    },
    {
      icon: FaMobileAlt,
      title: 'Mobile & Desktop',
      skills: ['Flutter', 'Dart', 'SQLite (offline)', 'Electron'],
      color: '#ec4899'
    },
    {
      icon: FaCloud,
      title: 'Tools & Workflow',
      skills: ['Git / GitHub', 'Docker (basic)', 'Linux', 'Google Apps Script', 'Figma'],
      color: '#f59e0b'
    },
    {
      icon: FaDesktop,
      title: 'Currently Learning',
      skills: ['AWS', 'Kubernetes', 'Terraform', 'Python'],
      color: '#8b5cf6'
    },
    {
      icon: FaRobot,
      title: 'AI Tools',
      skills: [
        'Claude',
        'ChatGPT',
        'Gemini',
        'GitHub Copilot',
        'DeepSeek',
        'Grok',
        'DeepSite',
        'Lovable',
        'Blackbox'
      ],
      color: '#6366f1'
    }
  ];

  return (
    <section id="skills" className="py-24 relative overflow-hidden" style={{ background: 'var(--bg-primary)' }}>
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-500/5 rounded-full blur-3xl"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-black mb-4" style={{ color: 'var(--text-primary)' }}>
              My <span className="gradient-text">Skills</span>
            </h2>
            <p className="max-w-2xl mx-auto text-sm" style={{ color: 'var(--text-secondary)' }}>
              What I work with — split by category and current level
            </p>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((category, index) => (
            <motion.div
              key={index}
              className="p-6 border transition-all duration-300 hover:border-indigo-500/30"
              style={{ 
                background: 'var(--bg-card)',
                borderColor: 'var(--border-color)'
              }}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -4 }}
            >
              <div className="flex items-center gap-4 mb-4">
                <div 
                  className="p-2.5"
                  style={{ background: `${category.color}15` }}
                >
                  <category.icon className="w-5 h-5" style={{ color: category.color }} />
                </div>
                <h3 className="text-base font-semibold" style={{ color: 'var(--text-primary)' }}>{category.title}</h3>
              </div>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill, idx) => (
                  <motion.span
                    key={idx}
                    className="text-xs px-3 py-1 border transition-all duration-200 hover:border-indigo-500/30"
                    style={{ 
                      color: 'var(--text-muted)',
                      borderColor: 'var(--border-color)',
                      background: 'var(--bg-primary)'
                    }}
                    whileHover={{ scale: 1.02 }}
                  >
                    {skill}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}